<?php
// Heading
$_['heading_title']    = 'Custom Module';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified - Custom Module!';
$_['text_edit']        = 'Edit - Custom Module';

// Entry
$_['entry_text']     = 'Enter text';
$_['entry_status']     = 'Status';
$_['tab_visits']     = 'Visits';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify - Custom Module!';
$_['text_no_results'] = 'No results!';